import React from "react";
import './App.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      toDoItems: [],
    };
  }
  componentDidMount() {
    // Answer 1
    const evenNumberArr = this.renderEvenNumber([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    console.log(evenNumberArr);


    // Answer 2
    const maxConsecutiveOnes = this.findMaxConsecutiveOnes([0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0]);
    console.log(maxConsecutiveOnes);

    // Answer 3
    const getConsecutiveArry = this.getConsecutive([0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0]);
    console.log(getConsecutiveArry);

    // Answer 4
    // We didn't use api yet. but I have theoretical knowledge only
    // For Api we can fetch method or Ajax 

    // Answer 5
    const obj = [
      { id: 4, name: 'abc' },
      { id: 10, name: 'ab2' },
      { id: 5, name: 'abc3' },
      { id: 6, name: 'abc5' }
    ]
    const sortedObj = this.sortObjectById(obj);
    console.log(sortedObj);

  }

  renderEvenNumber = (numberArray) => {
    let result = [];
    for (var i = 0; i < numberArray.length; i++) {
      if (numberArray[i] % 2 === 0)
        result.push(numberArray[i])
    }
    return result;
  }

  findMaxConsecutiveOnes = (numsArray) => {
    let largest = 0;
    let current = 0;
    let numsArrayVal = numsArray;
    for (let i = 0; i < numsArrayVal.length; i++) {
      if (numsArrayVal[i] === 0) {
        current = 0;
      } else {
        current++;
      }
      if (current > largest) {
        largest = current;
      }
    };
    return largest;
  };


  getConsecutive = (arr) => {
    var i, j, tempArry = [];
    for (i = 0; i < arr.length; i++) {
      for (j = i + 1; j < arr.length; j++) {
        if (arr[i] === arr[j]) {
          tempArry.push(arr[i]);
        } else {
          if (!tempArry.includes(arr[i])) {
            tempArry.push(arr[i])
          }
        }

      }
    }

    return tempArry
  }
  sortObjectById = (obj) => {
    let tempObj = []


    return tempObj
  }
  addToDoItem = () => {
    let temVale = "To do item 1";
    let temObj = { id: 1, value: temVale }
    this.setState({ toDoItems: temObj })
  }
  render() {
    let toDoItems = this.state.toDoItems;
    console.log(toDoItems);

    return <div className="container">
      <h3>To Items</h3>
      <ul>
        {toDoItems.map = item => {
            return <li>{item.value}</li>
          }}
      </ul>
      <div className="form-group">
        <label className="form-label" htmlFor="todotextbox">Add todo item</label>
        <input type="text" id="todotextbox" name="todotextbox" className="form-control" />
      </div>
      <button className="btn btn-primary" onClick={this.addToDoItem}>Add Item</button>
    </div>;
  }
}

export default App;